package com.nova.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Deep = Color(0xFF04111F)
private val Panel = Color(0xFF0A2235)
private val Cyan = Color(0xFF63DFFF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var speechReady = false
    private var onRecognized: ((String) -> Unit)? = null

    private val askAudio = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else onStatus?.invoke("Permissão do microfone negada.")
    }
    private var onStatus: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            NovaScreen(
                speak = { say(it) },
                listen = { callback, status ->
                    onRecognized = callback
                    onStatus = status
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) startListening()
                    else askAudio.launch(Manifest.permission.RECORD_AUDIO)
                }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "BR"))
            speechReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setSpeechRate(0.96f)
            tts?.setPitch(1.05f)
        }
    }

    private fun say(text: String) {
        if (speechReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova_reply")
    }

    private fun startListening() {
        val sr = recognizer ?: run { onStatus?.invoke("Reconhecimento de voz indisponível neste aparelho."); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a NOVA")
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onStatus?.invoke("Estou ouvindo...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onStatus?.invoke("Processando...") }
            override fun onError(error: Int) { onStatus?.invoke("Não consegui ouvir. Toque no microfone e tente novamente.") }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) onRecognized?.invoke(spoken)
                onStatus?.invoke("Pronta para ajudar.")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        sr.startListening(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
private fun NovaScreen(speak: (String) -> Unit, listen: ((String) -> Unit, (String) -> Unit) -> Unit) {
    val messages = remember { mutableStateListOf(ChatLine("Olá! Eu sou a NOVA. Toque no microfone ou escreva uma mensagem para conversarmos.", false)) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Pronta para ajudar.") }
    var voiceOn by remember { mutableStateOf(true) }

    fun reply(raw: String) {
        val q = raw.lowercase(Locale("pt", "BR"))
        val answer = when {
            q.startsWith("oi") || q.startsWith("olá") || q.startsWith("ola") ||
                q.startsWith("bom dia") || q.startsWith("boa tarde") || q.startsWith("boa noite") ->
                "Olá! Estou aqui. Como posso ajudar você?"
            "seu nome" in q || "quem é você" in q || "quem e voce" in q ->
                "Meu nome é NOVA, sua assistente pessoal. Esta é minha primeira versão."
            "horas" in q || "que horas" in q ->
                "Agora são " + SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date()) + "."
            "data" in q || "dia é hoje" in q || "dia e hoje" in q ->
                "Hoje é " + SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("pt", "BR")).format(Date()) + "."
            "ajuda" in q || "o que você faz" in q || "o que voce faz" in q ->
                "Por enquanto posso conversar, falar respostas e informar hora e data. Nas próximas versões vamos adicionar mais funções."
            "obrigad" in q -> "Por nada. Sempre que precisar, pode me chamar."
            "tchau" in q -> "Até mais. Estarei por aqui quando você voltar."
            else -> "Entendi. Ainda estou na versão inicial e não tenho uma inteligência artificial conectada. Essa será uma das próximas etapas."
        }
        messages.add(ChatLine(answer, false))
        if (voiceOn) speak(answer)
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isNotEmpty()) {
            messages.add(ChatLine(clean, true))
            input = ""
            reply(clean)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Deep, surface = Panel, primary = Cyan, onPrimary = Deep,
        onBackground = Color(0xFFEAF8FF), onSurface = Color(0xFFEAF8FF)
    )) {
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF102D45), Deep, Color(0xFF020810))))
        ) {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("N.O.V.A. / SYSTEM", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("● ONLINE", color = Color(0xFF9AB8C9), fontSize = 11.sp)
                }
                Spacer(Modifier.height(25.dp))
                Box(
                    Modifier.size(205.dp).background(Color(0xFF0A314B).copy(alpha = .45f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(178.dp).background(Color.Transparent, CircleShape))
                    Box(Modifier.size(126.dp).background(
                        Brush.radialGradient(listOf(Color(0xFFE9FFFF), Cyan, Color(0xFF087EAF), Color(0xFF031B32))),
                        CircleShape
                    ))
                }
                Spacer(Modifier.height(12.dp))
                Text("N O V A", color = Color(0xFFE4FAFF), fontSize = 29.sp, letterSpacing = 7.sp, fontWeight = FontWeight.Light)
                Text("ASSISTENTE PESSOAL", color = Color(0xFF75BCD4), fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(17.dp))
                Text(status, color = Color(0xFFA8C8D8), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    OutlinedButton(onClick = { voiceOn = !voiceOn }) { Text(if (voiceOn) "🔊 Voz ligada" else "🔇 Voz desligada") }
                    Button(
                        onClick = { listen({ send(it) }, { status = it }) },
                        modifier = Modifier.size(72.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D5274))
                    ) { Text("🎙", fontSize = 25.sp) }
                }
                Spacer(Modifier.height(16.dp))
                Surface(
                    Modifier.fillMaxWidth().weight(1f),
                    color = Panel.copy(alpha = .92f),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B4961))
                ) {
                    Column(Modifier.padding(13.dp)) {
                        Text("CANAL DE COMUNICAÇÃO", color = Color(0xFF6EBBD7), fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(messages) { line ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                                    Surface(color = if (line.fromUser) Color(0xFF123C55) else Color(0xFF0D2A3D), shape = RoundedCornerShape(12.dp)) {
                                        Text(line.text, Modifier.padding(10.dp), color = Color(0xFFE5F8FF), fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = input, onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("Escreva para NOVA...") },
                                singleLine = true
                            )
                            Button(onClick = { send(input) }, contentPadding = PaddingValues(horizontal = 13.dp, vertical = 15.dp)) {
                                Text("Enviar")
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("PROTÓTIPO 1.0 · VOZ E CONVERSA BÁSICA", color = Color(0xFF64889C), fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
    }
}
